# gunicorn_config.py

limit_request_line = 15000
limit_request_field_size = 15000
